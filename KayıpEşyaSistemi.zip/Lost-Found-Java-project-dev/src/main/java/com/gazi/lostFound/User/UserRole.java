
package com.gazi.lostFound.User;

//enum for roles
public enum UserRole {
    ROLE_ADMIN,
    ROLE_USER
}
