package com.vx.esyakayipsistemi.Trial;

public class Checking {
    public static void main(String[] args) {}
}