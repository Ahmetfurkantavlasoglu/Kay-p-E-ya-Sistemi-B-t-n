package com.vx.esyakayipsistemi.Trial;

import com.vx.esyakayipsistemi.Utils.ConfigUtils;
import com.vx.esyakayipsistemi.Utils.GlobalAuthHttpClient;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Paths;
import java.util.Map;

public class Main {
    public static void main(String[] args) throws Exception {
//        GlobalAuthHttpClient.setBasicAuth("mowassiradmin@gmail.com","mowassiradmin");
//
//        HttpResponse<String> response=GlobalAuthHttpClient.delete("http://localhost:8080/items");
//        String baseUrl =ConfigUtils.getProperty("app.baseUrl");
//        String url=baseUrl+"/itmes";
//        System.out.println(url);


    }
//
}